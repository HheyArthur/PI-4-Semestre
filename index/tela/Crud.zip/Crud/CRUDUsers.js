
const modal = document.querySelector('.modal-container');
const tbody = document.querySelector('tbody');
const btnSalvar = document.querySelector('#btnSalvar');

let itens = [];
let id;

function openModal(edit = false, index = 0) {
	modal.classList.add('active');

	modal.onclick = e => {
		if (e.target.className.indexOf('modal-container') !== -1) {
			modal.classList.remove('active');
		}
	};

	const sNome = document.querySelector('#m-nome');
	const sEmail = document.querySelector('#m-email');
	const sGrupo = document.querySelector('#m-grupo');

	if (edit) {
		sNome.value = itens[index].nome;
		sEmail.value = itens[index].Email;
		sEmail.disabled = true; // Desabilita o campo de email durante a edição
		sGrupo.value = itens[index].Grupo;
		id = index;
	} else {
		sNome.value = '';
		sEmail.value = '';
		sEmail.disabled = false; // Habilita o campo de email para uma nova inserção
		sGrupo.value = '';
	}
}

function editItem(index) {
	openModal(true, index);
}

function deleteItem(index) {
	itens.splice(index, 1);
	setItensBD();
	loadItens();
}

function insertItem(item, index) {
	let tr = document.createElement('tr');

	tr.innerHTML = `
		<td>${item.nome}</td>
		<td>${item.Email}</td>
		<td>${item.Grupo}</td>
		<td><button id="status-${index}" onclick="changeStatus(${index})">${item.status === 'ativo' ? 'Ativo' : 'Inativo'}</button></td>
		<td class="acao">
			<button onclick="editItem(${index})">Editar</button>
			<button onclick="deleteItem(${index})">Excluir</button>
		</td>
	`;

	tbody.appendChild(tr);
}

btnSalvar.onclick = e => {
	const sNome = document.querySelector('#m-nome');
	const sEmail = document.querySelector('#m-email');
	const sGrupo = document.querySelector('#m-grupo');

	if (sNome.value === '' || sEmail.value === '' || sGrupo.value === '') {
		return;
	}

	e.preventDefault();

	if (id !== undefined) {
		itens[id].nome = sNome.value;
		itens[id].Email = sEmail.value; // Mantém o email original durante a edição
		itens[id].Grupo = sGrupo.value;
	} else {
		itens.push({'nome': sNome.value, 'Email': sEmail.value, 'Grupo': sGrupo.value, 'status': 'ativo'});
	}

	setItensBD();

	modal.classList.remove('active');
	loadItens();
	id = undefined;
};

function loadItens() {
	tbody.innerHTML = '';
	itens.forEach((item, index) => {
		insertItem(item, index);
	});
}

const getItensBD = () => JSON.parse(localStorage.getItem('dbfunc')) || [];
const setItensBD = () => localStorage.setItem('dbfunc', JSON.stringify(itens));

loadItens();

function changeStatus(index) {
	if (itens[index].status === 'ativo') {
		itens[index].status = 'inativo';
	} else {
		itens[index].status = 'ativo';
	}

	setItensBD();
	loadItens();
}

